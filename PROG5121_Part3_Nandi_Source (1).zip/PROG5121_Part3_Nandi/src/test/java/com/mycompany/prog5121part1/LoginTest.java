package com.mycompany.prog5121part1;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/**
 * Unit tests for the Login class.
 *
 * @author Nandi Nkosi
 */
public class LoginTest {

    @Test
    public void validUsernameIsAccepted() {
        Login profile = new Login(
                "kyl_1",
                "Ch&&sec@ke99!",
                "+27838968976",
                "Matimba",
                "Hobyani"
        );

        assertTrue(profile.checkUserName());
    }

    @Test
    public void invalidUsernameIsRejected() {
        Login profile = new Login(
                "kyle!!!!!!!",
                "Ch&&sec@ke99!",
                "+27838968976",
                "Matimba",
                "Hobyani"
        );

        assertFalse(profile.checkUserName());
    }

    @Test
    public void validPasswordIsAccepted() {
        Login profile = new Login(
                "kyl_1",
                "Ch&&sec@ke99!",
                "+27838968976",
                "Matimba",
                "Hobyani"
        );

        assertTrue(profile.checkPasswordComplexity());
        assertEquals(
                "Username successfully captured.\n"
                + "Password successfully captured.\n"
                + "Cell phone number successfully added.",
                profile.registerUser()
        );
    }

    @Test
    public void invalidPasswordIsRejected() {
        Login profile = new Login(
                "kyl_1",
                "password",
                "+27838968976",
                "Matimba",
                "Hobyani"
        );

        assertFalse(profile.checkPasswordComplexity());
    }

    @Test
    public void validCellNumberIsAccepted() {
        Login profile = new Login(
                "kyl_1",
                "Ch&&sec@ke99!",
                "+27838968976",
                "Matimba",
                "Hobyani"
        );

        assertTrue(profile.checkCellPhoneNumber());
    }

    @Test
    public void invalidCellNumberIsRejected() {
        Login profile = new Login(
                "kyl_1",
                "Ch&&sec@ke99!",
                "08966553",
                "Matimba",
                "Hobyani"
        );

        assertFalse(profile.checkCellPhoneNumber());
    }

    @Test
    public void correctCredentialsAllowLogin() {
        Login profile = new Login(
                "kyl_1",
                "Ch&&sec@ke99!",
                "+27838968976",
                "Matimba",
                "Hobyani"
        );

        assertTrue(profile.loginUser("kyl_1", "Ch&&sec@ke99!"));
        assertEquals(
                "Welcome Matimba Hobyani it is great to see you again.",
                profile.returnLoginStatus(true)
        );
    }

    @Test
    public void incorrectCredentialsBlockLogin() {
        Login profile = new Login(
                "kyl_1",
                "Ch&&sec@ke99!",
                "+27838968976",
                "Matimba",
                "Hobyani"
        );

        assertFalse(profile.loginUser("wrong", "password"));
        assertEquals(
                "Username or password incorrect, please try again.",
                profile.returnLoginStatus(false)
        );
    }
}
