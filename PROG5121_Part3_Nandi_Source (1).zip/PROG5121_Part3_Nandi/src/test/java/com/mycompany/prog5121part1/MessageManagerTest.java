package com.mycompany.prog5121part1;

import static org.junit.jupiter.api.Assertions.*;
import java.nio.file.Path;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class MessageManagerTest {
    @TempDir Path temp;

    private MessageManager sampleManager() {
        MessageManager manager = new MessageManager(temp.resolve("stored_messages.json"));
        manager.loadPoeSampleData();
        return manager;
    }

    @Test void sentMessagesArrayContainsOnlySentExamples() {
        MessageManager manager = sampleManager();
        assertEquals(2, manager.sentMessageArray().length);
        assertEquals("Did you get the cake?", manager.sentMessageArray()[0].getMessageContent());
        assertEquals("It is dinner time !", manager.sentMessageArray()[1].getMessageContent());
    }

    @Test void longestStoredMessageIsReturned() {
        MessageManager manager = sampleManager();
        assertEquals("Where are you? You are late! I have asked you to be on time.",
                manager.findLongestStoredMessage().orElseThrow().getMessageContent());
    }

    @Test void searchByMessageIdReturnsMessageFour() {
        MessageManager manager = sampleManager();
        assertEquals("It is dinner time !", manager.findByMessageId("1000000004").orElseThrow().getMessageContent());
    }

    @Test void searchRecipientReturnsBothStoredMessages() {
        MessageManager manager = sampleManager();
        var found = manager.findByRecipient("+27838884567");
        assertEquals(2, found.size());
        assertEquals("Where are you? You are late! I have asked you to be on time.", found.get(0).getMessageContent());
        assertEquals("Ok, I am leaving without you.", found.get(1).getMessageContent());
    }

    @Test void deleteStoredMessageByHashRemovesMatchingMessage() {
        MessageManager manager = sampleManager();
        Message target = manager.findByMessageId("1000000002").orElseThrow();
        assertTrue(manager.deleteByHash(target.buildMessageHash()));
        assertTrue(manager.findByMessageId("1000000002").isEmpty());
        assertEquals(1, manager.storedMessageArray().length);
    }

    @Test void jsonFileCanBeReadBackIntoStoredArray() throws Exception {
        MessageManager first = sampleManager();
        MessageManager second = new MessageManager(temp.resolve("stored_messages.json"));
        second.loadStoredMessages();
        assertEquals(2, second.storedMessageArray().length);
        assertEquals("+27838884567", second.storedMessageArray()[0].getRecipientNumber());
    }

    @Test void reportContainsRequiredFieldsForEveryMessage() {
        String report = sampleManager().buildReport();
        assertTrue(report.contains("Message Hash:"));
        assertTrue(report.contains("Recipient:"));
        assertTrue(report.contains("Message:"));
        assertTrue(report.contains("Did you get the cake?"));
        assertTrue(report.contains("Ok, I am leaving without you."));
    }

    @Test void parallelArraysArePopulatedFromDataNotHardCodedInAccessors() {
        MessageManager manager = sampleManager();
        assertEquals(5, manager.messageIdArray().length);
        assertEquals(5, manager.messageHashArray().length);
        assertEquals(1, manager.disregardedMessageArray().length);
        assertEquals(2, manager.storedMessageArray().length);
    }
}
