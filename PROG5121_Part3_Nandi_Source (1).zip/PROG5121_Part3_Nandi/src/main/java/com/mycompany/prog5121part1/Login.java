package com.mycompany.prog5121part1;
import java.util.regex.Pattern;
/** Stores registration information and validates login credentials. */
public class Login {
 private final String userName,userPassword,mobileNumber,givenName,familyName;
 public Login(String u,String p,String m,String f,String l){userName=u;userPassword=p;mobileNumber=m;givenName=f;familyName=l;}
 public boolean validateUserName(){return userName!=null&&userName.contains("_")&&userName.length()<=5;}
 public boolean validatePassword(){return userPassword!=null&&userPassword.length()>=8&&userPassword.matches(".*[A-Z].*")&&userPassword.matches(".*\\d.*")&&userPassword.matches(".*[^a-zA-Z0-9].*");}
 public boolean validateMobileNumber(){return mobileNumber!=null&&Pattern.matches("^\\+27[6-8]\\d{8}$",mobileNumber);}
 public String completeRegistration(){if(!validateUserName())return "Username is not correctly formatted; please ensure that your userName contains an underscore and is no more than five characters in length.";if(!validatePassword())return "Password is not correctly formatted; please ensure that the userPassword contains at least eight characters, a capital letter, a number, and a special character.";if(!validateMobileNumber())return "Cell phone number incorrectly formatted or does not contain international code.";return "Username successfully captured.\nPassword successfully captured.\nCell phone number successfully added.";}
 public boolean authenticate(String u,String p){return userName.equals(u)&&userPassword.equals(p);}
 public String getLoginMessage(boolean ok){return ok?"Welcome "+givenName+", "+familyName+" it is great to see you again.":"Username or userPassword incorrect, please try again.";}
 public String getUserName(){return userName;}
 public String getGivenName(){return givenName;}
 public String getFamilyName(){return familyName;}
 // Compatibility methods retained for the Part 1 assessment tests.
 public boolean checkUserName(){return validateUserName();}
 public boolean checkPasswordComplexity(){return validatePassword();}
 public boolean checkCellPhoneNumber(){return validateMobileNumber();}
 public String registerUser(){return completeRegistration();}
 public boolean loginUser(String suppliedUsername,String suppliedPassword){return authenticate(suppliedUsername,suppliedPassword);}
 public String returnLoginStatus(boolean authenticated){return authenticated?"Welcome "+givenName+" "+familyName+" it is great to see you again.":"Username or password incorrect, please try again.";}
 public String getUsername(){return userName;}
}
