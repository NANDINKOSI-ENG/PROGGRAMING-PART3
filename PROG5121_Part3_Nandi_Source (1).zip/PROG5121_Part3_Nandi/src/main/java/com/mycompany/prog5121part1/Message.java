package com.mycompany.prog5121part1;

import java.util.Locale;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.concurrent.ThreadLocalRandom;
import java.util.regex.Pattern;

/** Represents one QuickChat message and its delivery state. */
public class Message {
    private final String messageIdentifier;
    private final int sequenceNumber;
    private final String recipientNumber;
    private final String message;
    private String messageStatus;

    @JsonCreator
    public Message(@JsonProperty("messageIdentifier") String messageIdentifier,
                   @JsonProperty("sequenceNumber") int sequenceNumber,
                   @JsonProperty("recipientNumber") String recipientNumber,
                   @JsonProperty("message") String message,
                   @JsonProperty("messageStatus") String messageStatus) {
        this.messageIdentifier = messageIdentifier;
        this.sequenceNumber = sequenceNumber;
        this.recipientNumber = recipientNumber;
        this.message = message;
        this.messageStatus = messageStatus;
    }

    public Message(String messageIdentifier, int sequenceNumber, String recipientNumber, String message) {
        this(messageIdentifier, sequenceNumber, recipientNumber, message, "Pending");
    }

    @JsonProperty("messageIdentifier")
    public String getMessageIdentifier() { return messageIdentifier; }
    @JsonProperty("sequenceNumber")
    public int getSequenceNumber() { return sequenceNumber; }
    @JsonProperty("recipientNumber")
    public String getRecipientNumber() { return recipientNumber; }
    @JsonProperty("message")
    public String getMessageContent() { return message; }
    @JsonProperty("messageStatus")
    public String getMessageStatus() { return messageStatus; }
    public void setMessageStatus(String status) { this.messageStatus = status; }
    @JsonIgnore
    public String getMessageHash() { return buildMessageHash(); }

    public boolean isValidMessageId() {
        return messageIdentifier != null && messageIdentifier.matches("\\d{1,10}");
    }

    /** Part 2 validation is retained: South African international number, +27 plus nine digits. */
    public String validateRecipient() {
        return recipientNumber != null && Pattern.matches("^\\+27[6-8]\\d{8}$", recipientNumber)
                ? "Cell phone number successfully captured."
                : "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
    }

    public boolean isWithinCharacterLimit() { return message != null && message.length() <= 250; }

    public String buildMessageHash() {
        if (messageIdentifier == null || messageIdentifier.length() < 2 || message == null) return "";
        String trimmed = message.trim();
        if (trimmed.isEmpty()) return messageIdentifier.substring(0, 2) + ":" + sequenceNumber + ":";
        String[] words = trimmed.split("\\s+");
        String first = words[0].replaceAll("[^A-Za-z0-9]", "");
        String last = words[words.length - 1].replaceAll("[^A-Za-z0-9]", "");
        return (messageIdentifier.substring(0, 2) + ":" + sequenceNumber + ":" + first + last)
                .toUpperCase(Locale.ROOT);
    }

    public String displayMessage() {
        return "Message ID: " + messageIdentifier + "\nMessage Hash: " + buildMessageHash()
                + "\nRecipient: " + recipientNumber + "\nMessage: " + message;
    }

    public static String createMessageId(int sequenceNumber) {
        return String.format("%010d", ThreadLocalRandom.current().nextLong(1_000_000_000L, 10_000_000_000L));
    }
}
