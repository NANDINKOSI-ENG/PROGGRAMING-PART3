package com.mycompany.prog5121part1;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.DeserializationFeature;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/** Holds the five required message arrays and JSON persistence operations. */
public class MessageManager {
    private final List<Message> sentMessages = new ArrayList<>();
    private final List<Message> disregardedMessages = new ArrayList<>();
    private final List<Message> storedMessages = new ArrayList<>();
    private final List<String> messageHashes = new ArrayList<>();
    private final List<String> messageIds = new ArrayList<>();
    private final ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    private final Path jsonFile;

    public MessageManager() { this(Path.of("stored_messages.json")); }
    public MessageManager(Path jsonFile) { this.jsonFile = jsonFile; }

    public void addMessage(Message message, String status) {
        message.setMessageStatus(status);
        messageHashes.add(message.buildMessageHash());
        messageIds.add(message.getMessageIdentifier());
        switch (status.toLowerCase()) {
            case "sent" -> sentMessages.add(message);
            case "disregarded", "discarded" -> disregardedMessages.add(message);
            case "stored" -> { storedMessages.add(message); saveStoredMessages(); }
            default -> throw new IllegalArgumentException("Unknown message status: " + status);
        }
    }

    public List<Message> getSentMessages() { return List.copyOf(sentMessages); }
    public List<Message> getDisregardedMessages() { return List.copyOf(disregardedMessages); }
    public List<Message> getStoredMessages() { return List.copyOf(storedMessages); }
    public List<String> getMessageHashes() { return List.copyOf(messageHashes); }
    public List<String> getMessageIds() { return List.copyOf(messageIds); }
    // Explicit array accessors align with the POE requirement to populate arrays.
    public Message[] sentMessageArray() { return sentMessages.toArray(new Message[0]); }
    public Message[] disregardedMessageArray() { return disregardedMessages.toArray(new Message[0]); }
    public Message[] storedMessageArray() { return storedMessages.toArray(new Message[0]); }
    public String[] messageHashArray() { return messageHashes.toArray(new String[0]); }
    public String[] messageIdArray() { return messageIds.toArray(new String[0]); }

    public String displayStoredSendersAndRecipients(String senderName) {
        if (storedMessages.isEmpty()) return "No stored messages found.";
        return storedMessages.stream().map(m -> "Sender: " + senderName + " | Recipient: " + m.getRecipientNumber())
                .collect(Collectors.joining(System.lineSeparator()));
    }

    public Optional<Message> findLongestStoredMessage() {
        return storedMessages.stream().max((a, b) -> Integer.compare(
                a.getMessageContent().length(), b.getMessageContent().length()));
    }

    public Optional<Message> findByMessageId(String id) {
        return allMessages().stream().filter(m -> m.getMessageIdentifier().equals(id)).findFirst();
    }

    public List<Message> findByRecipient(String recipient) {
        return allMessages().stream().filter(m -> m.getRecipientNumber().equals(recipient)).toList();
    }

    public boolean deleteByHash(String hash) {
        for (Message message : new ArrayList<>(storedMessages)) {
            if (message.buildMessageHash().equalsIgnoreCase(hash)) {
                storedMessages.remove(message);
                messageHashes.remove(message.buildMessageHash());
                messageIds.remove(message.getMessageIdentifier());
                saveStoredMessages();
                return true;
            }
        }
        return false;
    }

    public void loadStoredMessages() throws IOException {
        if (!Files.exists(jsonFile) || Files.size(jsonFile) == 0) return;
        List<Message> loaded = mapper.readValue(jsonFile.toFile(), new TypeReference<List<Message>>() {});
        storedMessages.clear();
        storedMessages.addAll(loaded);
        for (Message m : loaded) {
            if (!messageHashes.contains(m.buildMessageHash())) messageHashes.add(m.buildMessageHash());
            if (!messageIds.contains(m.getMessageIdentifier())) messageIds.add(m.getMessageIdentifier());
        }
    }

    public void saveStoredMessages() {
        try {
            Path parent = jsonFile.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            mapper.writerWithDefaultPrettyPrinter().writeValue(jsonFile.toFile(), storedMessages);
        } catch (IOException ex) {
            throw new IllegalStateException("Could not save stored messages to JSON: " + ex.getMessage(), ex);
        }
    }

    public String buildReport() {
        StringBuilder report = new StringBuilder("========== QUICKCHAT MESSAGE REPORT ==========\n");
        if (allMessages().isEmpty()) return report.append("No messages available.\n").toString();
        for (Message m : allMessages()) {
            report.append("Status: ").append(m.getMessageStatus()).append('\n')
                    .append("Message Hash: ").append(m.buildMessageHash()).append('\n')
                    .append("Recipient: ").append(m.getRecipientNumber()).append('\n')
                    .append("Message: ").append(m.getMessageContent()).append('\n')
                    .append("----------------------------------------------\n");
        }
        return report.toString();
    }

    private List<Message> allMessages() {
        List<Message> all = new ArrayList<>();
        all.addAll(sentMessages); all.addAll(storedMessages); all.addAll(disregardedMessages);
        return all;
    }

    /** Used to populate the required parallel arrays from the supplied POE test dataset. */
    public void loadPoeSampleData() {
        addMessage(new Message("1000000001", 0, "+27834557896", "Did you get the cake?", "Sent"), "Sent");
        addMessage(new Message("1000000002", 1, "+27838884567", "Where are you? You are late! I have asked you to be on time.", "Stored"), "Stored");
        addMessage(new Message("1000000003", 2, "+27834484567", "Yohoooo, I am at your gate.", "Disregarded"), "Disregarded");
        addMessage(new Message("1000000004", 3, "0838884567", "It is dinner time !", "Sent"), "Sent");
        addMessage(new Message("1000000005", 4, "+27838884567", "Ok, I am leaving without you.", "Stored"), "Stored");
    }
}
