package com.mycompany.prog5121part1;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

/** Console application: registration, login and QuickChat Part 1-3 features. */
public class Prog5121part1 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        ArrayList<Login> users = new ArrayList<>();
        boolean running = true;
        System.out.println("Welcome to the Registration and Login App!");
        while (running) {
            System.out.println("\nMain Menu:\n1. Register\n2. Login\n3. Exit\nPlease choose an option: ");
            switch (input.nextLine()) {
                case "1" -> register(input, users);
                case "2" -> login(input, users);
                case "3" -> { System.out.println("Goodbye!"); running = false; }
                default -> System.out.println("Invalid option. Please choose 1, 2 or 3.");
            }
        }
    }

    private static void register(Scanner in, ArrayList<Login> users) {
        System.out.print("First name: "); String first = in.nextLine();
        System.out.print("Last name: "); String last = in.nextLine();
        System.out.print("Username (underscore, max 5 characters): "); String username = in.nextLine();
        System.out.print("Password: "); String password = in.nextLine();
        System.out.print("Cell number (+27...): "); String cell = in.nextLine();
        Login account = new Login(username, password, cell, first, last);
        System.out.println(account.completeRegistration());
        if (!account.validateUserName() || !account.validatePassword() || !account.validateMobileNumber()) return;
        if (users.stream().anyMatch(u -> u.getUserName().equals(username))) {
            System.out.println("Username already exists."); return;
        }
        users.add(account); System.out.println("User registered successfully!");
    }

    private static void login(Scanner in, ArrayList<Login> users) {
        if (users.isEmpty()) { System.out.println("No users are registered yet. Please register first."); return; }
        System.out.print("Username: "); String username = in.nextLine();
        System.out.print("Password: "); String password = in.nextLine();
        for (Login account : users) {
            if (account.getUserName().equals(username)) {
                boolean ok = account.authenticate(username, password);
                System.out.println(account.getLoginMessage(ok));
                if (ok) runQuickChat(in, account);
                return;
            }
        }
        System.out.println("Username or password incorrect, please try again.");
    }

    private static void runQuickChat(Scanner in, Login account) {
        MessageManager manager = new MessageManager();
        try { manager.loadStoredMessages(); } catch (IOException ex) { System.out.println("Could not load JSON: " + ex.getMessage()); }
        System.out.println("\nWelcome to QuickChat.");
        int limit = readPositiveNumber(in, "How many messages would you like to enter? ");
        int entered = 0; boolean active = true;
        while (active) {
            System.out.println("\nQuickChat Menu:\n1. Send Messages\n2. Show recently sent messages\n3. Quit\n4. Stored Messages\nChoose: ");
            switch (in.nextLine()) {
                case "1" -> {
                    if (entered >= limit) { System.out.println("You have entered the set number of messages."); break; }
                    Message message = createMessage(in, entered);
                    if (message == null) break;
                    System.out.println("1. Send Message\n2. Disregard Message\n3. Store Message to send later\nChoose: ");
                    String choice = in.nextLine();
                    switch (choice) {
                        case "1" -> { manager.addMessage(message, "Sent"); System.out.println("Message successfully sent."); }
                        case "2" -> { manager.addMessage(message, "Disregarded"); System.out.println("Press 0 to delete the message."); }
                        case "3" -> { manager.addMessage(message, "Stored"); System.out.println("Message successfully stored."); }
                        default -> { System.out.println("Invalid choice; message not added."); continue; }
                    }
                    System.out.println(message.displayMessage()); entered++;
                }
                case "2" -> System.out.println(manager.getSentMessages().isEmpty() ? "No sent messages yet." : manager.getSentMessages().stream().map(Message::displayMessage).reduce("", (a,b) -> a + "\n" + b));
                case "3" -> { System.out.println("Total messages sent: " + manager.getSentMessages().size()); active = false; }
                case "4" -> storedMenu(in, manager, account.getGivenName() + " " + account.getFamilyName());
                default -> System.out.println("Invalid option. Please choose 1, 2, 3 or 4.");
            }
        }
    }

    private static Message createMessage(Scanner in, int number) {
        String id = Message.createMessageId(number);
        System.out.println("Message ID generated: " + id);
        System.out.print("Recipient cell number: "); String recipient = in.nextLine();
        System.out.print("Message (maximum 250 characters): "); String text = in.nextLine();
        Message message = new Message(id, number, recipient, text);
        if (!message.isValidMessageId()) { System.out.println("Invalid message ID."); return null; }
        if (!message.validateRecipient().equals("Cell phone number successfully captured.")) { System.out.println(message.validateRecipient()); return null; }
        if (!message.isWithinCharacterLimit()) { System.out.println("Message exceeds 250 characters by " + (text.length()-250) + "; please reduce the size."); return null; }
        return message;
    }

    private static void storedMenu(Scanner in, MessageManager manager, String sender) {
        boolean open = true;
        while (open) {
            System.out.println("\nStored Messages:\n1. Display sender and recipient\n2. Longest stored message\n3. Search by message ID\n4. Search by recipient\n5. Delete by message hash\n6. Display full message report\n7. Back\nChoose: ");
            switch (in.nextLine()) {
                case "1" -> System.out.println(manager.displayStoredSendersAndRecipients(sender));
                case "2" -> System.out.println(manager.findLongestStoredMessage().map(Message::displayMessage).orElse("No stored messages found."));
                case "3" -> { System.out.print("Message ID: "); String id=in.nextLine(); System.out.println(manager.findByMessageId(id).map(m -> "Recipient: "+m.getRecipientNumber()+"\nMessage: "+m.getMessageContent()).orElse("Message ID not found.")); }
                case "4" -> { System.out.print("Recipient number: "); String recipient=in.nextLine(); var found=manager.findByRecipient(recipient); if(found.isEmpty()) System.out.println("No messages found for this recipient."); else found.forEach(m -> System.out.println(m.getMessageStatus()+": "+m.getMessageContent())); }
                case "5" -> { System.out.print("Message hash: "); String hash=in.nextLine(); System.out.println(manager.deleteByHash(hash) ? "Message successfully deleted." : "Message hash not found."); }
                case "6" -> System.out.println(manager.buildReport());
                case "7" -> open=false;
                default -> System.out.println("Invalid option.");
            }
        }
    }

    private static int readPositiveNumber(Scanner in, String prompt) {
        while (true) { System.out.print(prompt); try { int n=Integer.parseInt(in.nextLine()); if(n>0) return n; } catch(NumberFormatException ignored) { } System.out.println("Please enter a positive whole number."); }
    }
}
