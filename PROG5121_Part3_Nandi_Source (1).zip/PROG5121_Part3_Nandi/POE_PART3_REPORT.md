# PROG5121/p/w — Programming 1A
## Part 3: Store Data and Display Task Report

**Student:** Nandi Nkosi  
**Student number:** ST10547934  
**Assessment:** Part 3 of the 2026 Portfolio of Evidence  

## 1. Introduction

This section extends the QuickChat console application developed in Parts 1 and 2. The application retains registration and login, message creation, message validation and message status selection. Part 3 adds dynamically populated message collections, stored-message retrieval from JSON, search and delete operations, a fourth menu option, and a message report.

## 2. Arrays and data organisation

The `MessageManager` class organises messages by status. It maintains collections for sent, disregarded and stored messages, together with parallel message-hash and message-ID collections. The collections grow as the user adds messages; values are not fixed in the menu code. Array accessor methods (`sentMessageArray`, `disregardedMessageArray`, `storedMessageArray`, `messageHashArray` and `messageIdArray`) return populated Java arrays for the POE array requirements.

| Required array | Data held |
|---|---|
| Sent Message | Messages whose status is Sent |
| Disregarded Messages | Messages whose status is Disregarded |
| Stored Messages | Messages whose status is Stored, loaded from JSON when available |
| Message Hash | Hash generated for each accepted message |
| Message ID | Unique ten-digit identifier for each accepted message |

## 3. Stored Messages menu

After a successful login, QuickChat displays four options. Option 4 opens the Stored Messages submenu:

1. Display sender and recipient for stored messages.
2. Find and display the longest stored message.
3. Search for a message ID and display the matching recipient and message.
4. Search for all messages associated with a recipient number.
5. Delete a stored message using its message hash.
6. Display a report of all messages.
7. Return to the QuickChat menu.

The application reports when no matching message is found instead of failing or displaying unrelated information.

## 4. JSON storage

The project uses the Jackson JSON library. When a message is stored, `MessageManager` writes the stored-message collection to `stored_messages.json`. At the start of QuickChat, `loadStoredMessages()` reads the JSON file into the stored-message collection. The file is rewritten after a stored message is deleted so that the JSON data remains consistent with the in-memory data.

## 5. Supplied Part 3 test data

The following five records are used by the repeatable sample-data method and the unit tests:

| No. | Recipient | Message | Status |
|---:|---|---|---|
| 1 | +27834557896 | Did you get the cake? | Sent |
| 2 | +27838884567 | Where are you? You are late! I have asked you to be on time. | Stored |
| 3 | +27834484567 | Yohoooo, I am at your gate. | Disregarded |
| 4 | 0838884567 | It is dinner time ! | Sent |
| 5 | +27838884567 | Ok, I am leaving without you. | Stored |

The supplied sample records are retained for repeatable demonstrations and unit testing. Message-ID lookup uses the generated ten-digit message identifier associated with each message.

## 6. Unit testing

`MessageManagerTest` contains tests for:

- Sent-message array population and expected message content.
- Finding the longest stored message.
- Searching by message ID and returning the corresponding message.
- Finding both messages associated with `+27838884567`.
- Deleting a stored message by its message hash.
- Reading stored messages back from the JSON file.
- Displaying a report containing message hash, recipient and message fields.
- Populating the message ID, message hash, stored and disregarded arrays.

Run the tests from the project directory using `mvn clean test`. The GitHub Actions workflow at `.github/workflows/TestJava.yml` is configured to execute the Maven tests on pushes and pull requests.

## 7. Running the application

1. Open the project as a Maven project in NetBeans.
2. Allow Maven to download the declared dependencies.
3. Run `mvn clean test` to execute the automated unit tests.
4. Run `com.mycompany.prog5121part1.Prog5121part1`.
5. Register a valid user and log in.
6. Send, disregard and store messages; then use option 4 to test each stored-message function.
7. The application saves stored messages to `stored_messages.json` and reloads them when QuickChat starts.
8. The GitHub Actions workflow runs the Maven test suite when the project is pushed to GitHub.

## 8. Conclusion

Part 3 extends the QuickChat application with dynamic message organisation, JSON persistence and retrieval, search, deletion and reporting. The accompanying unit tests target the principal operations required by the assessment rubric. The POE is accompanied by the Java source project, automated unit tests and GitHub Actions workflow.

## References

The Independent Institute of Education (Pty) Ltd. (2026). *PROG5121/p/w Programming 1A: Portfolio of Evidence (POE), 2026*. Assessment brief and marking rubric.

Fasterxml. (n.d.). *Jackson databind*. Available at: https://github.com/FasterXML/jackson-databind (Accessed: 19 November 2026).

JUnit Team. (n.d.). *JUnit 5 User Guide*. Available at: https://junit.org/junit5/docs/current/user-guide/ (Accessed: 19 November 2026).
