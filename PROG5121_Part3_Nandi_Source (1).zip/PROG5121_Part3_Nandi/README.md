# PROG5121 Programming 1A — Part 3 QuickChat

**Student:** Nandi Nkosi  
**Student number:** ST10547934

## Requirements
- Java 17
- Apache Maven 3.9+
- NetBeans or another Java IDE

## Run
Open this folder as a Maven project in NetBeans, or run:

```bash
mvn clean test
mvn package
```

Run `com.mycompany.prog5121part1.Prog5121part1` from the IDE after Maven dependencies have loaded.

## Part 3 implementation
The application retains registration/login and QuickChat, adds menu option 4 (Stored Messages), and supports sender/recipient display, longest stored message, ID lookup, recipient search, deletion by message hash, and a complete report. `MessageManager` maintains dynamically populated message collections and exposes Java arrays for sent, disregarded, stored, message hashes and message IDs. Stored messages are persisted in `stored_messages.json` using Jackson and can be loaded again when QuickChat starts.

The supplied Part 3 sample dataset is available through `MessageManager.loadPoeSampleData()` for repeatable demonstration and unit testing. The console application accepts user-entered messages and does not preload this sample data.

## Unit tests and CI
Run `mvn clean test` to execute the automated unit tests. GitHub Actions is configured in `.github/workflows/TestJava.yml` to run the tests on pushes and pull requests.
